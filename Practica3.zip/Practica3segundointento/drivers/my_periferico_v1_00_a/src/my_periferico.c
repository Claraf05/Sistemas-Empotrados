/*****************************************************************************
* Filename:          C:\hlocal\Practica3segundointento/drivers/my_periferico_v1_00_a/src/my_periferico.c
* Version:           1.00.a
* Description:       my_periferico Driver Source File
* Date:              Mon Oct 18 17:07:10 2021 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "my_periferico.h"

/************************** Function Definitions ***************************/

